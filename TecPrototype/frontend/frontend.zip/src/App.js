import React from 'react';
import './App.css';
import 'antd/dist/antd.css';
import $ from 'jquery';



import BasicRoute from './Router'


function App() {
  $(document).ready(function(){
    
  });


  return (
      <BasicRoute />

  );

}

export default App;
